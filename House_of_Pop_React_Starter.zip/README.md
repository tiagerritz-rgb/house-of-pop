# House of Pop

Starter project placeholder.

This package contains a project roadmap. The full React site will be built iteratively.
